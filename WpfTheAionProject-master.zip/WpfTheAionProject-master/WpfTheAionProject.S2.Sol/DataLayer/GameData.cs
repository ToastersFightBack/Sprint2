﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfTheAionProject.Models;

namespace WpfTheAionProject.DataLayer
{
    /// <summary>
    /// static class to store the game data set
    /// </summary>
    public static class GameData
    {
        public static Player PlayerData()
        {
            return new Player()
            {
                Id = 1,
                Name = "Dostya",
                Age = 43,
                Race = Character.RaceType.Cybran,
                Health = 100,
                Lives = 3,
                ThreatLevel = 5,
                LocationId = 0,
                FactionApproval = 100
            };
        }

        public static List<string> InitialMessages()
        {
            return new List<string>()
            {
                "If this shows something went wrong ? XD"
            };
        }

        public static GameMapCoordinates InitialGameMapLocation()
        {
            return new GameMapCoordinates() { Row = 0, Column = 0 };
        }

        public static Map GameMap()
        {
            int rows = 3;
            int columns = 4;

            Map gameMap = new Map(rows, columns);

            //
            // row 1
            //
            gameMap.MapLocations[0, 0] = new Location()
            {
                Id = 4,
                Name = "Headquarters",
                Description = "This is your faciton's diplomatic headquarters and where you will return every in game day to rest your characeter," +
                  "This is the only safe place in the game ",
                Accessible = true,
            };
            return gameMap;
        }
    }
}
